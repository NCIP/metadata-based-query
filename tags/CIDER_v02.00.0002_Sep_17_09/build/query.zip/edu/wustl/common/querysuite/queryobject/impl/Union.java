package edu.wustl.common.querysuite.queryobject.impl;

/**
 * @author vijay_pande
 * Class for the union operation for composite query
 */
public class Union extends Operation
{

}
