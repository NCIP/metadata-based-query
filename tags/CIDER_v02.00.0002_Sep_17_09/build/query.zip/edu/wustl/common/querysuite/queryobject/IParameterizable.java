package edu.wustl.common.querysuite.queryobject;

/**
 * Marker to represent parameterizable classes.
 * 
 * @author srinath_k
 */
public interface IParameterizable {

}
