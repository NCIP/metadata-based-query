package edu.wustl.common.querysuite.queryobject.impl;


/**
 * @author vijay_pande
 * Class for the minus operation for composite query
 */
public class Minus extends Operation
{

}
