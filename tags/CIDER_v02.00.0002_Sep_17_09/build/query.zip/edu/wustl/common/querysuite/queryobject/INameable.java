package edu.wustl.common.querysuite.queryobject;

public interface INameable {
    String getName();

    void setName(String name);
}
