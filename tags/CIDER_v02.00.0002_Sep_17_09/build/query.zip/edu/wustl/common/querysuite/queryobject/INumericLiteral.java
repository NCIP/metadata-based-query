package edu.wustl.common.querysuite.queryobject;

public interface INumericLiteral extends ILiteral {
    String getNumber();

    void setNumber(String literal);
}
