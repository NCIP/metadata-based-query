package edu.wustl.common.querysuite.queryobject.impl;


/**
 * @author vijay_pande
 * Class for the intersection operation for composite query
 */
public class Intersection extends Operation
{

}
