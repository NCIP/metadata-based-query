package edu.wustl.common.querysuite.queryobject;

public interface IDescribable {
    String getDescription();

    void setDescription(String desc);
}
